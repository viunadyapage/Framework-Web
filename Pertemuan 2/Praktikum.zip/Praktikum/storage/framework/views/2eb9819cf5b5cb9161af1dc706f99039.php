<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laravel</title>
</head>
<body>
    <h1>Selamat Datang di Laravel</h1>
    <a href="<?php echo e(route('contact')); ?>">Kontak</a>
    <a href="<?php echo e(route('about')); ?>">About</a>
</body>
</html>
<?php /**PATH C:\Users\kukib\pert2-fpweb\resources\views/welcome.blade.php ENDPATH**/ ?>